package com.rccode.enumeration;

public enum Command {
    LOAN, PAYMENT, BALANCE;
}
